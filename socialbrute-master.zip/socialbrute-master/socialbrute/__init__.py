# -*- coding: utf-8 -*-

"""Top-level package for socialbrute."""

__author__ = """5h4d0wb0y"""
__email__ = '5h4d0wb0y@protonmail.com'
__version__ = '1.1.0'
__description__ = 'SocialBrute attempts to crack social networks using a brute force dictionary attack.'
__copyright__ = "2019, 5h4dowboy"