===========
socialbrute
===========


.. image:: https://img.shields.io/pypi/v/socialbrute.svg
        :target: https://pypi.python.org/pypi/socialbrute

.. image:: https://img.shields.io/pypi/pyversions/socialbrute.svg
        :target: https://pypi.python.org/pypi/socialbrute

.. image:: https://readthedocs.org/projects/socialbrute/badge/?version=latest
        :target: https://socialbrute.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://travis-ci.com/5h4d0wb0y/socialbrute.svg?branch=master
        :target: https://travis-ci.com/5h4d0wb0y/socialbrute

.. image:: https://codecov.io/github/5h4d0wb0y/socialbrute/coverage.svg?branch=master
        :target: https://codecov.io/github/5h4d0wb0y/socialbrute?branch=master



SocialBrute attempts to crack a social network using a brute force dictionary attack.


* Free software: GNU General Public License v3
* Documentation: https://socialbrute.readthedocs.io.


Features
--------

* Browser supports proxy configuration
* Social network supported
        * Aol
        * Facebook
        * Gmail
        * Hotmail
        * Instagram
        * Twitter
        * VK
        * Yahoo
        * Spotify
        * Netflix
        * Gitlab
        * Github
        * Linkedin


Credits
-------

This package was developed by @5h4d0wb0y_.

.. _@5h4d0wb0y: https://twitter.com/5h4d0wb0y


Stargazers over time
--------------------

.. image:: https://starchart.cc/5h4d0wb0y/socialbrute.svg
        :target: https://starchart.cc/5h4d0wb0y/socialbrute
        :alt: Stargazers over time
